/*  MString - Dynamic string data type library
    Copyright (C) 2000 Jesse L. Lovelace

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef MSTRING_H
#define MSTRING_H

/*  MString by Jesse Lovelace (mentat)
	jllovela@eos.ncsu.edu

    (MString began as GString but was changed to remain compatible with
	gtk+'s GString data type.)

	http://www4.ncsu.edu/~jllovela/MString/

	MString is a string library that uses dynamically sizable character
	strings.  To do this I used linked lists instead of dynamic arrays for
	various reasons (one being the problems that arrays of dynamic arrays
	cause).

	MString is designed to maintain compatibility with the MFC CString
	library.  MString should be 99% compatible if you exclude the windoze
	specific operations (including buffer access) and the .Format commands.

	For the full documentation see functions.txt

	MString also includes the MStringArray class.  MStringArray follows the
	same scheme as CStringArray from MFC.  CStringArrays are also linked
	lists for now (I may change them to dynamically allocated arrays in the
	future).

	Please submit any suggestions/bugs/comments to jllovela@eos.ncsu.edu

	Enjoy.

	Thanks to:  Dingo - pointer debugging, 
				Rask - math and Trim(char ch), 
				Botch - debugging and advice

	(Last modified March 23, 2000)
*/

const int MAX_PRECISION = 9; //due to bad double to string code.
const char MString_VERSION[8] = ".3.1";

#include <fstream.h>

class MNode;

class MString {

//Begin overloaded stream functions -----------------------

	friend ostream& operator<< (ostream& out, const MString& string); 
	// PRE: out is a valid output stream, string is a valid MString
	// POST: contents of string are sent to stream out.

	friend istream& operator>> (istream& in, MString& string); 
	// PRE: in is a valid input stream, string is a valid MString
	// POST: characters in input stream are stored in string.

	friend istream& getline(istream& in, MString& string); 
	// PRE: in is valid input stream, sting is a valid MString
	// POST: characters up to (and including) the newline are stored 
	//       in string.
	// EX: getline(in, string);

//End overloaded stream functions -------------------------

public:

//Begin Constructors --------------------------------------

	MString(); 
	// Info: construct empty MString
	
	MString(const MString& stringSrc); 
	// Info: copy constructor
	// PRE: stringSrc is a valid MString object.
	// POST: new object is a deep copy of stringSrc.

	MString(char ch, int nRepeat = 1); 
	// Info: construct with single character repeated nRepeat times
	// PRE: ch is a valid ascii character and non null.
	// POST: new object contains ch repeated nRepeat times.

	MString(char string[]); 
	// PRE: string is a valid null-terminated string.
	// POST: new object contains the data from string minues null.

	~MString(); 
	// Info: destructor

//End Constructors ----------------------------------------

//Begin Test Functions ------------------------------------

	void testG();
	// Info: uses cout to display the data and pointer of each
	//       Node.

	MString GetGVersion();
	// Info: returns the current version of MString.
	// POST: returns an object of type MString containing version info

	MString ReturnLicense();
	// Info: returns license info
	// POST: returns an object of type MString containing license info


//End Test Functions --------------------------------------

//Begin Precision Functions -------------------------------

	void SetPrecision(int num);
	// PRE: num <= MAX_PRECISION
	// POST: double conversion precision changed to num.

	int GetPrecision() const;
	// POST: returns an int type equal to the current double precision.

//End Precision Functions ---------------------------------

//Begin String as Array Functions -------------------------
	
	int GetLength() const; 
	// Info: returns the length of the string excluding null

	bool IsEmpty() const;  
	// Info: nonzero if string has 0 length
	
	void Empty();  
	// Info: empty's the string and free's memory
	
	char GetAt(int nIndex) const; 
	// Info: returns char at index
	
	char operator [](int nIndex) const; 
	// Info: operator overload of GetAt(int nIndex)

	void SetAt(int nIndex, char ch); 
	// Info: sets the character at nIndex

//End String as Array Functions ---------------------------

//Begin Assignment/Concatination operators ----------------

	const MString& operator =(const MString& stringSrc); //Idea from CString
	const MString& operator =(char ch);
	const MString& operator =(char string[]);
	const MString& operator =(int num); //Original MString
	const MString& operator =(double num); //Original MString
	const MString& operator =(float num); //Original MString

	const MString& operator +=(const MString& string); //Idea from CString
	const MString& operator +=(char ch);
	const MString& operator +=(char string[]);
	const MString& operator +=(int num); //Original MString
	const MString& operator +=(double num); //Original MString
	const MString& operator +=(float num); //Original MString

	friend MString operator +(const MString& string1, const MString& string2);
	friend MString operator +(const MString& string, char ch);
	friend MString operator +(char ch, const MString& string);
	friend MString operator +(const MString& string, char ch[]);
	friend MString operator +(char ch[], const MString& string);


//End Assignment/Concatination operators ------------------

//Begin Comparison operators ------------------------------

	friend bool operator==(const MString& s1, const MString& s2); //Idea from CString
	friend bool operator==(const MString& s1, char s2[]); 
	friend bool operator==(char s1[], const MString& s2); 

	friend bool operator!=(const MString& s1, const MString& s2); //Idea from CString
	friend bool operator!=(const MString& s1, char s2[]);
	friend bool operator!=(char s1[], const MString& s2);

	friend bool operator <(const MString& s1, const MString& s2); //Idea from CString
	friend bool operator <(const MString& s1, char s2[]);
	friend bool operator <(char s1[], const MString& s2);

	friend bool operator >(const MString& s1, const MString& s2); //Idea from CString
	friend bool operator >(const MString& s1, char s2[]);
	friend bool operator >(char s1[], const MString& s2);

	friend bool operator <=(const MString& s1, const MString& s2); //Idea from CString
	friend bool operator <=(const MString& s1, char s2[]);
	friend bool operator <=(char s1[], const MString& s2);

	friend bool operator >=(const MString& s1, const MString& s2); //Idea from CString
	friend bool operator >=(const MString& s1, char s2[]);
	friend bool operator >=(char s1[], const MString& s2);

	int Compare(char string[]) const; //Idea from CString
	int Compare(MString string) const; //MString original
	int CompareNoCase(char string[]) const; //Idea from CString
	int Collate(char string[]) const; //Idea from CString
	int CollateNoCase(char string[]) const; //Idea from CString

//End Comparison operators --------------------------------

//Begin Extraction operators ------------------------------

	MString Mid(int nFirst) const;  //Idea from CString
	MString Mid(int nFirst, int nCount) const; //Idea from CString
	MString Left(int nCount) const; //Idea from CString
	MString Right(int nCount) const; //Idea from CString
	MString SpanIncluding(char string[]) const; //Idea from CString
	MString SpanExcluding(char string[]) const; //Idea from CString

//End Extraction operators --------------------------------

//Begin Other Conversions ---------------------------------
	
	void MakeUpper(); //Idea from CString
	void MakeLower(); //Idea from CString
	void MakeReverse(); //Idea from CString

	int Replace(char chOld, char chNew); //Idea from CString
	int Replace(char stringOld[], char stringNew[]); //Idea from CString
	int Remove(char ch); //Idea from CString
	int Insert(int nIndex, char ch); //Idea from CString
	int Insert(int nIndex, char string[]); //Idea from CString
	int Delete(int nIndex, int nCount = 1); //Idea from CString

	//Research Format

	void Trim(); //Original MString
	void Trim(char ch); //Original MString
	void Trim(char string[]);

	void TrimLeft(); //Idea from CString
	void TrimLeft(char ch);
	void TrimLeft(char string[]);


	void TrimRight(); //Idea from CString
	void TrimRight(char ch);
	void TrimRight(char string[]);

//End Other Conversions -----------------------------------

	//Research FormatMessage

//Begin Searching -----------------------------------------

	int Find(char ch, int nStart = 0) const; //Idea from CString
	int Find(char string[], int nStart = 0) const; //Idea from CString


	int ReverseFind(char ch) const; //Idea from CString
	int ReverseFind(char string[]) const; //MString original
	int FindOneOf(char string[]) const; //Idea from CString

//End Searching -------------------------------------------

	//Buffer Access and Windows-Specific items not included.

private:

	MNode* GetPointerAt(int nIndex);
	
	MNode *headMNode;
	MNode *tailMNode; //New for .3b

	int precision;

};

#endif