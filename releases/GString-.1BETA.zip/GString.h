/*  GString - Dynamic string data type library
    Copyright (C) 2000 Jesse L. Lovelace

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef GSTRING_H
#define GSTRING_H

/*  GString by Jesse Lovelace (mentat)
	jllovela@eos.ncsu.edu

	http://www4.ncsu.edu/~jllovela/GString/

	GString is a string library that uses dynamically sizable character
	strings.  To do this I used linked lists instead of dynamic arrays for
	various reasons (one being the problems that arrays of dynamic arrays
	cause).

	GString is designed to maintain compatibility with the MFC CString
	library.  GString should be 99% compatible if you exclude the windoze
	specific operations (including buffer access) and the .Format commands.

	New functions not included in the MFC Cstring are:

  		const GString& operator =(int num); 
		const GString& operator =(double num); 
		const GString& operator =(float num);

		const GString& operator +=(int num);
		const GString& operator +=(double num);
		const GString& operator +=(float num); 
		
		void Trim(); 
		void Trim(char ch);
		void Trim(char string[]);

		void SetPrecision(int num) const;
		int GetPrecision() const;
		
	For the full documentation see functions.txt

	GString also includes the GStringArray class.  GStringArray follows the
	same scheme as CStringArray from MFC.  CStringArrays are also linked
	lists for now (I may change them to dynamically allocated arrays in the
	future).

	GString is not related to the gstring library by PC Drew.  GString was 
	created before I knew of the gstring class and is completely original
	code (not to mention the fact that I use linked lists).

	Please submit any suggestions/bugs/comments to jllovela@eos.ncsu.edu

	Enjoy.

	Thanks to:  Dingo - pointer debugging, 
				Rask - math and Trim(char ch), 
				Botch - debugging and advice

	(Last modified March 23, 2000)
*/

const int MAX_PRECISION = 9; //due to bad double to string code.
const char GSTRING_VERSION[8] = ".1 BETA";

#include <fstream.h>

class GNode {
public:
	GNode(char ch, GNode* link = 0) {GLink_Forward = link; GInfo = ch; } 
	GNode *GLink_Forward;
	char GInfo;
};

class GString {

//Begin overloaded stream functions -----------------------

	friend ostream& operator<< (ostream& out, const GString& string); //Original GString
	friend istream& operator>> (istream& in, GString& string); //Original GString
	friend istream& getline(istream& in, GString& string); //Idea from APString

//End overloaded stream functions -------------------------

public:

//Begin Constructors --------------------------------------

	GString(); // construct empty GString operator
	GString(const GString& stringSrc); //construct with GString
	GString(char ch, int nRepeat = 1); // construct with single character
	GString(char string[]); // construct with string
	~GString(); //destructor

//End Constructors ----------------------------------------

//Begin Test Functions ------------------------------------

	void testG();
	GString GetGVersion();


//End Test Functions --------------------------------------

//Begin Precision Functions -------------------------------

	void SetPrecision(int num);
	int GetPrecision() const;

//End Precision Functions ---------------------------------

//Begin String as Array Functions -------------------------
	
	int GetLength() const; //returns the length of the string excluding null
	bool IsEmpty() const;  //nonzero if string has 0 length
	void Empty();  //empty's the string and free's memory
	char GetAt(int nIndex) const; // returns char at index
	char operator [](int nIndex) const; //same as GetAt

	void SetAt(int nIndex, char ch); // sets the character at nIndex

//End String as Array Functions ---------------------------

//Begin Assignment/Concatination operators ----------------

	const GString& operator =(const GString& stringSrc); //Idea from CString
	const GString& operator =(char ch);
	const GString& operator =(char string[]);
	const GString& operator =(int num); //Original GString
	const GString& operator =(double num); //Original GString
	const GString& operator =(float num); //Original GString

	const GString& operator +=(const GString& string); //Idea from CString
	const GString& operator +=(char ch);
	const GString& operator +=(char string[]);
	const GString& operator +=(int num); //Original GString
	const GString& operator +=(double num); //Original GString
	const GString& operator +=(float num); //Original GString

	friend GString operator +(const GString& string1, const GString& string2);
	friend GString operator +(const GString& string, char ch);
	friend GString operator +(char ch, const GString& string);
	friend GString operator +(const GString& string, char ch[]);
	friend GString operator +(char ch[], const GString& string);


//End Assignment/Concatination operators ------------------

//Begin Comparison operators ------------------------------

	friend bool operator==(const GString& s1, const GString& s2); //Idea from CString
	friend bool operator==(const GString& s1, char s2[]); 
	friend bool operator==(char s1[], const GString& s2); 

	friend bool operator!=(const GString& s1, const GString& s2); //Idea from CString
	friend bool operator!=(const GString& s1, char s2[]);
	friend bool operator!=(char s1[], const GString& s2);

	friend bool operator <(const GString& s1, const GString& s2); //Idea from CString
	friend bool operator <(const GString& s1, char s2[]);
	friend bool operator <(char s1[], const GString& s2);

	friend bool operator >(const GString& s1, const GString& s2); //Idea from CString
	friend bool operator >(const GString& s1, char s2[]);
	friend bool operator >(char s1[], const GString& s2);

	friend bool operator <=(const GString& s1, const GString& s2); //Idea from CString
	friend bool operator <=(const GString& s1, char s2[]);
	friend bool operator <=(char s1[], const GString& s2);

	friend bool operator >=(const GString& s1, const GString& s2); //Idea from CString
	friend bool operator >=(const GString& s1, char s2[]);
	friend bool operator >=(char s1[], const GString& s2);

	int Compare(char string[]) const; //Idea from CString
	int Compare(GString string) const; //GString original
	int CompareNoCase(char string[]) const; //Idea from CString
	int Collate(char string[]) const; //Idea from CString
	int CollateNoCase(char string[]) const; //Idea from CString

//End Comparison operators --------------------------------

//Begin Extraction operators ------------------------------

	GString Mid(int nFirst) const;  //Idea from CString
	GString Mid(int nFirst, int nCount) const; //Idea from CString
	GString Left(int nCount) const; //Idea from CString
	GString Right(int nCount) const; //Idea from CString
	GString SpanIncluding(char string[]) const; //Idea from CString
	GString SpanExcluding(char string[]) const; //Idea from CString

//End Extraction operators --------------------------------

//Begin Other Conversions ---------------------------------
	
	void MakeUpper(); //Idea from CString
	void MakeLower(); //Idea from CString
	void MakeReverse(); //Idea from CString

	int Replace(char chOld, char chNew); //Idea from CString
	int Replace(char stringOld[], char stringNew[]); //Idea from CString
	int Remove(char ch); //Idea from CString
	int Insert(int nIndex, char ch); //Idea from CString
	int Insert(int nIndex, char string[]); //Idea from CString
	int Delete(int nIndex, int nCount = 1); //Idea from CString

	//Research Format

	void Trim(); //Original GString
	void Trim(char ch); //Original GString
	void Trim(char string[]);

	void TrimLeft(); //Idea from CString
	void TrimLeft(char ch);
	void TrimLeft(char string[]);


	void TrimRight(); //Idea from CString
	void TrimRight(char ch);
	void TrimRight(char string[]);

//End Other Conversions -----------------------------------

	//Research FormatMessage

//Begin Searching -----------------------------------------

	int Find(char ch, int nStart = 0) const; //Idea from CString
	int Find(char string[], int nStart = 0) const; //Idea from CString


	int ReverseFind(char ch) const; //Idea from CString
	int ReverseFind(char string[]) const; //GString original
	int FindOneOf(char string[]) const; //Idea from CString

//End Searching -------------------------------------------

	//Buffer Access and Windows-Specific items not included.

private:

	GNode* GetPointerAt(int nIndex);
	
	GNode *headGNode;
	int precision;

};

#endif