/*  GString - Dynamic string data type library
    Copyright (C) 2000 Jesse L. Lovelace

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#include "GString.h"


//Begin Static Functions ---------------------------------

static GNode* copy(GNode* p)
{
	GNode* head = 0;
	GNode* tail = 0;

	while(p) {
		if (!head)
			head = tail = new GNode(p->GInfo);
		else {
			tail->GLink_Forward = new GNode(p->GInfo);
			tail = tail->GLink_Forward;
		}
		p = p->GLink_Forward;
	}
	return head;
}
static void deallocate(GNode* p)
{
	GNode* tmp;
	while (p) {
		tmp = p;
		p = p->GLink_Forward;
		delete tmp;
	}
}

static int isString(char string[])
{
	int count = 0;
	while( string[count] != '\0') {
		if (count > 10000) //why? because something is wrong by now
			return -1;

		count++;
	}

	return count;
}

GNode* GString::GetPointerAt(int nIndex) {

	GNode* tmp = headGNode;
	
	for (int i = 0; (i < nIndex); i++) {

		if (NULL == tmp)
			return NULL;

		tmp = tmp->GLink_Forward;
	}
	return tmp;
}


//End Static Functions ------------------------------------

//Begin Constructors --------------------------------------

GString::~GString() {
	deallocate(headGNode);
	headGNode = 0;
}

GString::GString() {
	headGNode = NULL;
	precision = 3;
}

GString::GString(const GString &stringSrc) {
	headGNode = copy(stringSrc.headGNode);
	precision = 3;
}

GString::GString(char ch, int nRepeat) {
	if (nRepeat < 1) 
		return;

	headGNode = new GNode(ch);
	nRepeat--;
	GNode *tmp = headGNode;

	for (int i=0; i < nRepeat; i++) {
		tmp->GLink_Forward = new GNode(ch);
		tmp = tmp->GLink_Forward;
	}
	precision = 3;
}


GString::GString(char string[]) {

	int i = 0;
	
	headGNode = new GNode(string[i]);
	GNode *tmp = headGNode;


	for (i = 1; string[i] != '\0'; i++) {
		tmp->GLink_Forward = new GNode(string[i]);

		tmp=tmp->GLink_Forward;
	}

	precision = 3;

}

//End Constructors ----------------------------------------

//Begin Test Functions ------------------------------------

void GString::testG() {

	GNode *tmp = headGNode;


	while (tmp)
	{ 
		cout << tmp->GInfo << " " << tmp->GLink_Forward << endl;
		tmp = tmp->GLink_Forward;
	}
}

GString GString::GetGVersion() {

	GString tmp;
	
	for (int i = 0; GSTRING_VERSION[i] != '\0'; i++)
		tmp += GSTRING_VERSION[i];
	return tmp;
}


//End Test Functions --------------------------------------

//Begin Precision Functions -------------------------------

void GString::SetPrecision(int num){
	if (num > MAX_PRECISION)  //
		return;
	precision = num;
}

int GString::GetPrecision() const {

	return precision;
}

//End Precision Functions ---------------------------------

//Begin String as Array Functions -------------------------

int GString::GetLength() const {

	int length = 0;

	if (headGNode) {
	
		GNode* tmp = headGNode;
		while (tmp) {  //while pointer is not null, count characters.
			length++;
			tmp=tmp->GLink_Forward;  //next node.
		}
	}
	return length;
}

bool GString::IsEmpty() const {

	if (headGNode)
		return false;
	else 
		return true;
}

void GString::Empty()
{
	deallocate(headGNode);
	headGNode = 0;
}

char GString::GetAt(int nIndex) const {

	if ((nIndex < 0) || (nIndex > GetLength()) || (IsEmpty()))
		return 0;   //return's null if the nIndex is to big or small.

	GNode* tmp = headGNode;

	for (int i = 0; i < nIndex; i++)
		tmp=tmp->GLink_Forward;

	return tmp->GInfo;
}

char GString::operator [](int nIndex) const {
	
	return GetAt(nIndex);
}

void GString::SetAt(int nIndex, char ch) {
	
	if ((nIndex < 0) || (nIndex > GetLength()) || (IsEmpty()))
		return;

	GNode* tmp = headGNode;

	for (int i = 0; i < nIndex; i++)
		tmp=tmp->GLink_Forward;

	tmp->GInfo = ch;
}

//End String as Array Functions ---------------------------


//Begin overloaded stream functions -----------------------


ostream& operator<< (ostream& out, const GString& string) {

	if (string.IsEmpty())
		return out;

	GNode* tmp = string.headGNode; //because friend, access via dot
	while (tmp) {   //while tmp not null go on
		out << tmp->GInfo;
		tmp = tmp->GLink_Forward;
	}
	return out;
}

istream& operator>> (istream& in, GString& string) {

	char ch;
	while (in) {
	
		in >> ch;
		string += ch;
	}

	return in;
}

istream& getline(istream& in, GString& string) { //Idea from APString

	char ch;
	while(in && ('\n' != ch)) {

		in >> ch;
		string += ch;
	}
	
	if ('\n' == ch) 
		string += ch;

	return in;
}


//End overloaded stream functions -------------------------

//Begin Assignment/Concatination operators ----------------


const GString& GString::operator=(const GString& stringSrc) {

	if (this != &stringSrc) {

		deallocate(headGNode);
		headGNode = copy(stringSrc.headGNode);
	}

	return *this;
}

const GString& GString::operator=(char ch) {

	deallocate(headGNode);
	headGNode = new GNode(ch);

	return *this;
}

const GString& GString::operator=(char string[]) {

	deallocate(headGNode);

	int i = 0;
	
	headGNode = new GNode(string[i]);
	GNode *tmp = headGNode;


	for (i = 1; string[i] != '\0'; i++) {
		tmp->GLink_Forward = new GNode(string[i]);

		tmp=tmp->GLink_Forward;
	}

	return *this;

}


const GString& GString::operator =(int num) { //Original GString

	//Thanks to Rask for the math!
	deallocate(headGNode);

	int k = 1,
		single = 0;
	GString tmp;
	
	while ((num % (k)) < num) {
		single = (num % (10 * k))/k;
		tmp += char(single + '0'); //Thanks to botch for reminding me about '0'
		k = k * 10;

	}
	tmp.MakeReverse();
	headGNode = copy(tmp.headGNode);
	return *this;

}

const GString& GString::operator =(double num) { //Original GString

	deallocate(headGNode);

	GString tmp;
	tmp.SetPrecision(GetPrecision());
	tmp += num;

	headGNode = copy(tmp.headGNode);
	return *this;
}

const GString& GString::operator =(float num) { //Original GString

	deallocate(headGNode);

	GString tmp;
	tmp.SetPrecision(GetPrecision());
	tmp += num;

	headGNode = copy(tmp.headGNode);
	return *this;

}


GString operator +(const GString& string1, const GString& string2) {
	
	GString tmpStr;

	if (string1.IsEmpty()) {
		if (string2.IsEmpty())
			return tmpStr;
		else {
			tmpStr = string2;
			return tmpStr;
		}
	}
	else if (string2.IsEmpty()) {
		tmpStr = string1;
		return tmpStr;
	}

	tmpStr = string1;
	tmpStr += string2;

	return tmpStr;
}

GString operator +(const GString& string, char ch) {

	GString tmpStr;
	if (string.IsEmpty()) {
		tmpStr = ch;
		return tmpStr;
		
	}	

	tmpStr = string;
	tmpStr += ch;

	return tmpStr;

}

GString operator +(char ch, const GString& string) {

	GString tmpStr;
	if (string.IsEmpty()) {
		tmpStr = ch;
		return tmpStr;
	}

	tmpStr = ch;
	tmpStr += string;

	return tmpStr;
}


GString operator +(const GString& string, char ch[]) {

	GString tmpStr;
	if (string.IsEmpty()) {
		if (isString(ch) < 1)
			return tmpStr;
		else {
			tmpStr = ch;
			return tmpStr;
		}
	}
	else if (isString(ch) < 1) {
		tmpStr = string;
		return tmpStr;
	}

	tmpStr = string;
	tmpStr += ch;

	return tmpStr;
}

GString operator +(char ch[], const GString& string) {

	GString tmpStr;
	if (isString(ch) < 1) {
		if (string.IsEmpty())
			return tmpStr;
		else {
			tmpStr = string;
			return tmpStr;
		}
	}
	else if (string.IsEmpty()) {
		tmpStr = ch;
		return tmpStr;
	}

	tmpStr = ch;
	tmpStr += string;

	return tmpStr;
}

const GString& GString::operator +=(const GString& string) { 
//Idea from CString

	if (IsEmpty()) {
		headGNode = copy(string.headGNode);
		return *this;
	}
	GNode *tmp = headGNode;
	GNode *ref = string.headGNode;

	while (tmp->GLink_Forward) {
		tmp = tmp->GLink_Forward;
	}

	
	for (int i = 0; (ref); i++) {
	
		tmp->GLink_Forward = new GNode(string[i]);
		tmp = tmp->GLink_Forward;
		ref = ref->GLink_Forward;
	
	}
		
	return *this;
}

const GString& GString::operator +=(char ch) {

	if (IsEmpty()) {
		headGNode = new GNode(ch);
		return *this;
	}

	GNode *tmp = headGNode;

	while (tmp->GLink_Forward) {
		tmp = tmp->GLink_Forward;
	}
	
	tmp->GLink_Forward = new GNode(ch);

	return *this;
}

const GString& GString::operator +=(char string[]) {
	
	GNode *tmp = headGNode;

	while (tmp->GLink_Forward) {
		tmp = tmp->GLink_Forward;
	}
	
	for (int i = 0; string[i] != '\0'; i++) {
	
		tmp->GLink_Forward = new GNode(string[i]);
		tmp = tmp->GLink_Forward;
	
	}
		
	return *this;
}

const GString& GString::operator +=(int num) { 
	
	//Original GString function
	//Concatinates a integer to a string (woohoo!)
	
	GString tmpStr;
	int k = 1,
		single = 0;

	
	while ((num % (k)) < num) {
		single = (num % (10 * k))/k;
		tmpStr += char(single + '0'); 
		//Thanks to botch for reminding me about '0'
		k = k * 10;

	}
	tmpStr.MakeReverse();  
	//numbers are in reverse order, need to straighten

	if (IsEmpty())  { 
		// if string is empty use static copy function
		headGNode = copy(tmpStr.headGNode);
	}
	else {
		GNode *tmp = headGNode;

		while (tmp->GLink_Forward) {
			tmp = tmp->GLink_Forward;
		}
	
		for (int i = 0; (tmpStr.GetPointerAt(i)); i++) {  
			//this could be faster
	
			tmp->GLink_Forward = new GNode(tmpStr[i]); 
			//by using parallel list 
			//traversing (going through
			//tmpStr instead of using [])
			tmp = tmp->GLink_Forward;

		}
	}
		
	return *this;
}
const GString& GString::operator +=(double num) { 
	//Original GString

	GString tmpStr, tmpStr2, final;

	int k = 1,
		single = 0;

	long int num1 = int(num),
		power = 1;


	//THIS IS NOT A GOOD IMPLIMENTATION
	//Ideas would be helpful


	while ((num1 % (k)) < num1) {
		single = (num1 % (10 * k))/k;
		tmpStr += char(single + '0'); 
		//Thanks to botch for reminding me about '0'
		k = k * 10;

	}

	tmpStr.MakeReverse();  
	//numbers are in reverse order, need to straighten


	for (int i = 0; i < precision; i++) {
		power = power * 10;
	}

	num1 = int((num - num1) * power);
	single = 0; 
	k = 1;

	while ((num1 % (k)) < num1) {
		single = (num1 % (10 * k))/k;
		tmpStr2 += char(single + '0'); 
		//Thanks to botch for reminding me about '0'
		k = k * 10;

	}

	tmpStr2.MakeReverse();

	if (!tmpStr2.IsEmpty()) 
		tmpStr = tmpStr + '.' + tmpStr2;



	if (IsEmpty())  { 
		// if string is empty use static copy function
		headGNode = copy(tmpStr.headGNode);
	}
	else {
		GNode *tmp = headGNode;

		while (tmp->GLink_Forward) {
			tmp = tmp->GLink_Forward;
		}
	
		for (int i = 0; (tmpStr.GetPointerAt(i)); i++) {  
			//this could be faster
	
			tmp->GLink_Forward = new GNode(tmpStr[i]); 
			tmp = tmp->GLink_Forward;

		}
	}
		
	return *this;

}

const GString& GString::operator +=(float num) { 
	//Original GString

	GString tmpStr, tmpStr2, final;

	int k = 1,
		single = 0;

	long int num1 = int(num),
		power = 1;


	//THIS IS NOT A GOOD IMPLIMENTATION
	//Ideas would be helpful


	while ((num1 % (k)) < num1) {
		single = (num1 % (10 * k))/k;
		tmpStr += char(single + '0'); 
		//Thanks to botch for reminding me about '0'
		k = k * 10;

	}

	tmpStr.MakeReverse();  
	//numbers are in reverse order, need to straighten


	for (int i = 0; i < precision; i++) {
		power = power * 10;
	}

	num1 = int((num - num1) * power);
	single = 0; 
	k = 1;

	while ((num1 % (k)) < num1) {
		single = (num1 % (10 * k))/k;
		tmpStr2 += char(single + '0'); //Thanks to botch for reminding me about '0'
		k = k * 10;

	}

	tmpStr2.MakeReverse();

	tmpStr = tmpStr + '.' + tmpStr2;



	if (IsEmpty())  { // if string is empty use static copy function
		headGNode = copy(tmpStr.headGNode);
	}
	else {
		GNode *tmp = headGNode;

		while (tmp->GLink_Forward) {
			tmp = tmp->GLink_Forward;
		}
	
		for (int i = 0; (tmpStr.GetPointerAt(i)); i++) {  
			//this could be faster
	
			tmp->GLink_Forward = new GNode(tmpStr[i]); 
			tmp = tmp->GLink_Forward;				

		}
	}
		
	return *this;
}



//End Assignment/Concatination operators ------------------

//Begin Comparison operators ------------------------------

bool operator==(const GString& s1, const GString& s2) { 
	//Idea from CString

	if (s1.Compare(s2) != 0)
		return false;
	return true;
}


bool operator==(const GString& s1, char s2[]) {

	if (s1.Compare(s2) != 0)
		return false;
	return true;
}

bool operator==(char s1[], const GString& s2) {

	if (s2.Compare(s1) != 0)
		return false;
	return true;
}

bool operator!=(const GString& s1, const GString& s2) { 
	//Idea from CString

	if (s1 == s2)
		return false;
	else 
		return true;
}

bool operator!=(const GString& s1, char s2[]) {
	
	if (s1 == s2)
		return false;
	else 
		return true;
}

bool operator!=(char s1[], const GString& s2) {

	if (s1 == s2)
		return false;
	else 
		return true;
}

bool operator <(const GString& s1, const GString& s2) { 
	//Idea from CString

	if (s1.Compare(s2) < 0)
		return true;
	else 
		return false;
}

bool operator <(const GString& s1, char s2[]) {
	
	if (s1.Compare(s2) < 0)
		return true;
	else 
		return false;
}

bool operator <(char s1[], const GString& s2) {

	GString tmpStr(s1);

	if (tmpStr.Compare(s2) < 0)
		return true;
	else
		return false;
}

bool operator >(const GString& s1, const GString& s2) { 
	//Idea from CString

	if (s1.Compare(s2) > 0)
		return true;
	else 
		return false;
}

bool operator >(const GString& s1, char s2[]) {

	if (s1.Compare(s2) > 0)
		return true;
	else 
		return false;
}

bool operator >(char s1[], const GString& s2) {


	GString tmpStr(s1);

	if (tmpStr.Compare(s2) > 0)
		return true;
	else
		return false;
}

bool operator <=(const GString& s1, const GString& s2) { 
	//Idea from CString

	if (s1.Compare(s2) <= 0)
		return true;
	else 
		return false;
}

bool operator <=(const GString& s1, char s2[]){
	
	if (s1.Compare(s2) <= 0)
		return true;
	else 
		return false;
}

bool operator <=(char s1[], const GString& s2) {

	GString tmpStr(s1);

	if (tmpStr.Compare(s2) < 0)
		return true;
	else
		return false;
}

bool operator >=(const GString& s1, const GString& s2) { //Idea from CString

	if (s1.Compare(s2) >= 0)
		return true;
	else 
		return false;
}

bool operator >=(const GString& s1, char s2[]) {

	if (s1.Compare(s2) >= 0)
		return true;
	else 
		return false;
}

bool operator >=(char s1[], const GString& s2){

	GString tmpStr(s1);

	if (tmpStr.Compare(s2) < 0)
		return true;
	else
		return false;
}


int GString::Compare(char string[]) const { //Idea from CString

	GString tmpStr1(string);	
	//This function is pretty well optimized
	//because i didn't use [] but traversed list

	GNode *tmpString = tmpStr1.headGNode;
	GNode *tmp = headGNode;

	for (int i = 0; ((tmp) && (tmpString)); i++) {

		if (tmp->GInfo > tmpString->GInfo) 
			return (i + 1);		
		//because what if we are at index 0?

		if (tmp->GInfo < tmpString->GInfo)
			return ((i + 1) * -1);
		tmp=tmp->GLink_Forward;
		tmpString = tmpString->GLink_Forward;
	}
	return 0;

}

int GString::Compare(GString string) const {

	GNode *tmpString = string.headGNode;
	GNode *tmp = headGNode;

	for (int i = 0; ((tmp) && (tmpString)); i++) {

		if (tmp->GInfo > tmpString->GInfo) 
			return i;
		if (tmp->GInfo < tmpString->GInfo)
			return (i * -1);
		tmp=tmp->GLink_Forward;
		tmpString = tmpString->GLink_Forward;
	}
	return 0;
}



int GString::CompareNoCase(char string[]) const { 
	//Idea from CString

	GString tmpStr1(string);
	GString tmpStr2;
	tmpStr2.headGNode = copy(headGNode);

	tmpStr1.MakeLower();
	tmpStr2.MakeLower();


	GNode *tmpString = tmpStr1.headGNode;
	GNode *tmp = tmpStr2.headGNode;

	for (int i = 0; ((tmp) && (tmpString)); i++) {

		if (tmp->GInfo > tmpString->GInfo) 
			return i;
		if (tmp->GInfo < tmpString->GInfo)
			return (i * -1);
		tmp=tmp->GLink_Forward;
		tmpString = tmpString->GLink_Forward;
	}
	return 0;
}
int GString::Collate(char string[]) const{ 
	//Idea from CString

	//WARNING, COLLATE CURRENTLY IS THE SAME AS COMPARE
	//BECAUSE I DON'T KNOW HOW TO IMPLIMENT IT.

	return Compare(string);
}

int GString::CollateNoCase(char string[]) const{ 
	//Idea from CString

	//WARNING, COLLATE CURRENTLY IS THE SAME AS COMPARE
	//BECAUSE I DON'T KNOW HOW TO IMPLIMENT IT.

	return CompareNoCase(string);
}


//End Comparison operators --------------------------------

//Begin Extraction operators ------------------------------

GString GString::Mid(int nFirst) const {  
	//Idea from CString

	GString tmp;

	int length = GetLength();

	if (IsEmpty() || (nFirst > length))
		return tmp;

	for (int i = nFirst; i < length; i++) {
	
		tmp += GetAt(i);
	}
	return tmp;
}

GString GString::Mid(int nFirst, int nCount) const { 
	//Idea from CString

	GString tmp;

	int length = GetLength(),
		bound = 0;

	if (IsEmpty() || (nFirst > length))
		return tmp;

	if (nCount > length)
		bound = length;
	else 
		bound = nFirst + nCount;
	
	for (int i = nFirst; i < bound; i++) {

		tmp += GetAt(i);
	}
	return tmp;

}
GString GString::Left(int nCount) const { 
	//Idea from CString

	GString tmp;

	int bound = 0,
		length = GetLength();

	if (IsEmpty())
		return tmp;

	if (nCount > length)
		bound = length;
	else bound = nCount;

	for (int i = 0; i < bound; i++) {
		tmp += GetAt(i);
	}
	return tmp;

}

GString GString::Right(int nCount) const { 
	//Idea from CString

	GString tmp;

	if (IsEmpty())
		return tmp;	

	int bound = 0,
		length = GetLength();

	if (nCount > length)
		bound = length;
	else bound = nCount;

	for (int i = (length - bound); i < length; i++) {

		tmp += GetAt(i);

	}
	return tmp;
}

GString GString::SpanIncluding(char string[]) const { 
	//Idea from CString

	GString tmp;

	if (IsEmpty() || (isString(string) < 1))
		return tmp;

	int length = GetLength();

	for (int i = 0; i < length; i++) {
		
		int strCount = 0;
		while (string[strCount] != '\0') {

			if (GetAt(i) == string[strCount])
				tmp += string[strCount];

			strCount++;

		}
		if (tmp.IsEmpty())
			return tmp;
	}
	return tmp;
}

GString GString::SpanExcluding(char string[]) const { 
	//Idea from CString

	GString tmp;

	if (IsEmpty() || (isString(string) < 1))
		return tmp;

	int length = GetLength();
	bool isIn = false;

	for (int i = 0; i < length; i++) {
		
		int strCount = 0;
		while (string[strCount] != '\0') {

			if (GetAt(i) == string[strCount])
				isIn = true;
			strCount++;
		}
		if (isIn == false)
			tmp += GetAt(i);
		isIn = false;
		
	}
	return tmp;
}

//End Extraction operators --------------------------------

//Begin Other Conversions ---------------------------------


void GString::MakeUpper() { 
	//Idea from CString

	if (IsEmpty())
		return;

	char ch;
	int length = GetLength();

	for (int i = 0; i < length; i++) {
		ch = GetAt(i);
		if ((ch >= 97) && (ch <= 122))
			SetAt(i, ch - 32);
	}
}

void GString::MakeLower() { //Idea from CString

	if (IsEmpty())
		return;

	char ch;
	int length = GetLength();

	for (int i = 0; i < length; i++) {

		ch = GetAt(i);
		if ((ch >= 65) && (ch <= 90))
			SetAt(i, ch + 32);
	}
}
	
void GString::MakeReverse() {

	if (IsEmpty())
		return;

	GString tmp;
	int length = GetLength();

	for (int i = (length - 1); i >= 0; i--) {
	
		tmp += GetAt(i);
	}
	Empty();
	headGNode = copy(tmp.headGNode);
}

int GString::Replace(char chOld, char chNew) { 
	//Idea from CString

	if (IsEmpty()) 
		return 0;

	GString tmp;
	int timesReplaced = 0,
		length = GetLength();

	for (int i = 0; i < length; i++) {
		
		if (GetAt(i) == chOld) {
			SetAt(i, chNew);
			timesReplaced++;
		}

	}

	return timesReplaced;
}


int GString::Replace(char stringOld[], char stringNew[]) { 
	//Idea from CString


	int size1 = isString(stringOld),
		size2 = isString(stringNew),
		length = GetLength(),
		count = 0;

	if ( (length == 0) || (size1 < 1) || (size2 < 2) ) {
		return 0;
	}

	while (Find(stringOld) >= 0 ) {
		int place = Find(stringOld);
		Delete(place, size1);
		Insert(place, stringNew);
		count++;
	}
	


	return 0;
}
	
int GString::Remove(char ch){ 
	//Idea from CString  
	//TO DO: add string remove.

	int count = 0;
	while (Find(ch) >= 0) {
		Delete(Find(ch));
		count++;
	}

	return count;
}

int GString::Insert(int nIndex, char ch) { 
	//Idea from CString

	int length = GetLength();

	if (nIndex >= length)
		nIndex = length;


	if (0 == nIndex) {
		headGNode = new GNode(ch, headGNode);
	}
	else {
		GetPointerAt(nIndex - 1)->GLink_Forward =
			new GNode(ch, GetPointerAt(nIndex - 1)->GLink_Forward);
	}

	return GetLength();

}


int GString::Insert(int nIndex, char string[]) { 
	//Idea from CString

	int length = GetLength();

	if (nIndex >= length)
		nIndex = length;

	for (int i = 0; string[i] != '\0'; i++) {
		Insert(nIndex++, string[i]);
	}

	return GetLength();
}
		
int GString::Delete(int nIndex, int nCount) { 
	//Idea from CString

	int length = GetLength();

	if ((length < 1) || (nIndex > length) || (nCount < 1))
		return length;

	if (nCount > (length - nIndex))
		nCount = (length - nIndex);

	if (0 == nIndex) {
		GNode* first = headGNode;
		GNode* last = GetPointerAt((nIndex + nCount)-1);
	
		if (last->GLink_Forward) {
			if (last->GLink_Forward->GLink_Forward) {
				headGNode = last->GLink_Forward;
				last->GLink_Forward = NULL;
				deallocate(first);
			}
		}
		else {
			headGNode = NULL;
			deallocate(first);
		}

	}	
	else {
		GNode* toHead = GetPointerAt(nIndex - 1);
		GNode* first = GetPointerAt(nIndex);

		GNode* last = GetPointerAt((nCount + nIndex) - 1);
	
		if (last->GLink_Forward) {
			if (last->GLink_Forward->GLink_Forward) {
				toHead->GLink_Forward = last->GLink_Forward;
				last->GLink_Forward = NULL;
				deallocate(first);
			}
			else {
				toHead->GLink_Forward=last->GLink_Forward;
				last->GLink_Forward = NULL;
				deallocate(first);
			}
		}
		else {
			toHead->GLink_Forward = NULL;
			deallocate(first);
		}
	}

	return GetLength();

}

void GString::Trim() { 
	//Original GString

	TrimLeft();
	TrimRight();

}

void GString::Trim(char ch) { 
	//Original GString

	TrimLeft(ch);
	TrimRight(ch);

}
void GString::Trim(char string[]){

	TrimLeft(string);
	TrimRight(string);


}	

void GString::TrimLeft() { 
	//Idea from CString

	TrimLeft(' ');
	TrimLeft('\t');
	TrimLeft('\n');

}


void GString::TrimLeft(char ch) {
	if (IsEmpty())
		return;

	// not using a "int length" because it will change constantly.
	while(Find(ch) == 0) {
		Delete(Find(ch));

	}
}

void GString::TrimLeft(char string[]) {

	if (IsEmpty())
		return;	
	int strLen = isString(string);
	while(Find(string) == 0) {
		Delete(0, strLen);
	}
}

void GString::TrimRight() { 
	//Idea from CString

	TrimRight(' ');
	TrimRight('\t');
	TrimRight('\n');
}

void GString::TrimRight(char ch) {
	
	if (IsEmpty())
		return;	
	
	// not using a "int length" because it will change constantly.
	while ( ReverseFind(ch) == (GetLength() - 1)) {
		
	Delete(ReverseFind(ch));

	}
}


void GString::TrimRight(char string[]) {

	if (IsEmpty())
		return;	

	int strLen = isString(string);

	if (strLen > GetLength())
		return;

	while ( ReverseFind(string) == ( GetLength() - strLen ) ) {
		Delete(ReverseFind(string), strLen); 
	}

}

//End Other Conversions -----------------------------------

//Begin Searching -----------------------------------------

int GString::Find(char ch, int nStart) const { 
	//Idea from CString

	if (IsEmpty()) 
		return -1;


	int length = GetLength();

	for (int i = nStart; i < length; i++) {
		
		if (GetAt(i) == ch) {
			return i;
		}

	}

	return -1;
}


int GString::Find(char string[], int nStart) const { 
	//Idea from CString

	if (IsEmpty()) //if GString is empty return.
		return -1;

	int length = GetLength(),
		strLength = isString(string);
	bool found = false;



	if ((strLength > length) || (strLength < 1))  
		//if bigger than GString or not a string.
		return -1;

	for (int i = nStart; i < length; i++) {


		if (GetAt(i) == string[0]) { 

			int strPos = 0;
			
			for (int k = i; k < (i + strLength); k++) {
				if  (GetAt(k) == string[strPos++])
					found = true;
				else {
					found = false;
					break;
				}
			}
			if (found == true)
				return i;
		}
	}
	return -1;
	
}

int GString::ReverseFind(char ch) const { //Idea from CString


	if (IsEmpty()) 
		return -1;


	int length = GetLength();

	for (int i = (length - 1); i >= 0; i--) {
		
		if (GetAt(i) == ch) {
			return i;
		}

	}

	return -1;
}

int GString::ReverseFind(char string[]) const {

	if (IsEmpty()) 
		return -1;

	int length = GetLength(),
		strLen = isString(string);

	bool found = false;

	if (strLen < 1)
		return -1;

	for (int i = (length - strLen); i >= 0; i--) {
		if (GetAt(i) == string[0]) { 

			int strPos = 0;
			
			for (int k = i; k < (i + strLen); k++) {
				if  (GetAt(k) == string[strPos++])
					found = true;
				else {
					found = false;
					break;
				}
			}
			if (found == true)
				return i;
		}
	}
	return -1;
}


int GString::FindOneOf(char string[]) const { 
	//Idea from CString

	int strLen = isString(string);

	for (int i = 0; i < strLen; i++) {
		if (Find(string[i]) >= 0)
			return i;
	}

	return -1;
}


//End Searching -------------------------------------------